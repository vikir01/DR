<?php
	session_start();
	if(session_destroy()) {// Destroying All Sessions {
		header("location: index.html"); // Redirecting To Home Page
	}
?>